-- MariaDB dump 10.19  Distrib 10.4.27-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.4.27-MariaDB-1:10.4.27+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` float DEFAULT NULL,
  `milage` int(11) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `video` text DEFAULT NULL,
  `features` longtext DEFAULT NULL,
  `vin` varchar(255) DEFAULT NULL,
  `image` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cars_vin_idx` (`vin`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cars`
--

LOCK TABLES `cars` WRITE;
/*!40000 ALTER TABLE `cars` DISABLE KEYS */;
INSERT INTO `cars` VALUES (1,'2022 Chevrolet Silverado 1500',50000,123233,'sed do eiusmod tempor incididunt','asd','asd','1GCUDDED0NZ617281','https://vehicle-photos-published.vauto.com/f2/47/2a/ea-af61-44b4-b8f7-94d209ed85ff/image-1.jpg'),(2,'2023 Buick Envision\n',80000,32512,'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt',NULL,NULL,'LRBFZNR45PD024590','https://vehicle-photos-published.vauto.com/6d/ee/79/9f-fd60-49cd-a86b-327c3d04d919/image-1.jpg'),(3,'2023 Buick Envision',45000,123123,'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt',NULL,NULL,'LRBAZLR47PD024279','https://vehicle-photos-published.vauto.com/b8/71/da/cd-4e4d-4cb5-8cdf-5edf94458baa/image-1.jpg'),(4,'2023 GMC Sierra 1500',37000,41232,'Ut sem viverra aliquet eget. Dui sapien eget mi proin nam at lectus',NULL,NULL,'3GNAXNEG4PL156162','https://vehicle-photos-published.vauto.com/83/55/c4/b9-c615-4a13-8e23-1c739e14b2c8/image-2.jpg'),(5,'2023 GMC Terrain',50000,89322,'at nam at lectus',NULL,NULL,'KL4CJESM8NB568445','https://vehicle-photos-published.vauto.com/eb/f0/d1/c6-da40-4e69-8918-b4f7c96a8d73/image-1.jpg'),(6,'2023 Chevrolet Silverado 1500',34000,60422,'viverra aliquet eget. Dui sapien eget mi proin sed. Consectetur a erat nam at lectus',NULL,NULL,'1GTUUCE88PZ244698','https://vehicle-photos-published.vauto.com/ed/3b/08/fe-e758-452f-b5a2-9bab8dc889d2/image-3.jpg');
/*!40000 ALTER TABLE `cars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_idx` (`email`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Saphura Long','admin@gratis.com','$2y$10$PTLTs3GwbXjqZiJjjLb/HugywBVTHsLp5m0NoBaAhQ.wzGNXUYIKG');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-20  1:30:19
